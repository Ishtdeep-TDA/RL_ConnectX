Information of each python file

Coach.py - This is the main file which has the driver code for the learning.
Game.py - This uses the connectx environment to covert it into the correct format for the 
alphazero algorithm
main.py - Driver code for running the algorithm
MCTS.py - Contains most of the code for the MCTS algorithm
NeuralNet.py - Contains all the code for the Neural network class
NNet_model.py - contains the model of the neural network
simplified_connectx.py - contains the gym environment for connectx

To reproduce the results
1. run the main.py file to train the algorithm
2. 